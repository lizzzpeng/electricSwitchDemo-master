<template>
  <div>
    <PageContainer></PageContainer>
  </div>
</template>

<script>
import PageContainer from './components/PageContainer.vue'
export default {
  name: 'App',
  components: {
    PageContainer,
}
}
</script>

<style>
*{
  font-family:SimSun ;
}
</style>
