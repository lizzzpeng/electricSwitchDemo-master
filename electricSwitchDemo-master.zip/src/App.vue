<template>
  <div>
    <!-- <PageContainer></PageContainer> -->
  <router-view></router-view>
  </div>
</template>

<script>
// import PageContainer from './components/PageContainer.vue'
// import LoginBegin from './components/PageContainer.vue'
// import LoginBegin from './components/LoginBegin.vue';
export default {
  name: 'App',
  components: {
    // LoginBegin,
    

}, 

}
</script>

<style>
*{
  font-family:SimSun ;
}
</style>
